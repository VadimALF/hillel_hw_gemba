'use strict'

function Hamburger(humb) {
  this.humb = humb
  let price = humb.price
  let callories = humb.callories

  this.addTopping = function (topping) {
    //alert (this.price + this.topping)
    price += topping.price
    callories += topping.callories
  }
  
  this.getPrice = function () {return price}
  this.getCallories = function () {return callories}
}

Hamburger.SIZE_SMALL = {
    price: 50,
    callories: 20,
  }

Hamburger.SIZE_MEDIUM = {
    price: 75,
    callories: 30,
  }

Hamburger.SIZE_LARGE = {
    price: 100,
    callories: 40,
}

Hamburger.TOPPING_CHEESE = {
    price: 10,
    callories: 20,
}

Hamburger.TOPPING_SALAD = {
    price: 20,
    callories: 5,
}

Hamburger.TOPPING_POTATO = {
    price: 15,
    callories: 10,
}

Hamburger.TOPPING_POTATO = {
    price: 15,
    callories: 10,
}

Hamburger.TOPPING_MAYO = {
    price: 20,
    callories: 5,
}

Hamburger.TOPPING_SPICE = {
    price: 15,
    callories: 0,
}

const hamburgerSmall = new Hamburger(Hamburger.SIZE_SMALL)
const hamburgerLarge = new Hamburger(Hamburger.SIZE_LARGE)

hamburgerSmall.addTopping(Hamburger.TOPPING_MAYO)
hamburgerSmall.addTopping(Hamburger.TOPPING_MAYO)
hamburgerSmall.addTopping(Hamburger.TOPPING_CHEESE)
hamburgerLarge.addTopping(Hamburger.TOPPING_SALAD)
hamburgerLarge.addTopping(Hamburger.TOPPING_POTATO)

console.log("Price SMALL with sauce: " + hamburgerSmall.getPrice());
console.log("Callories SMALL with sauce: " + hamburgerSmall.getCallories());
console.log("--------------")
console.log("Price LARGE with sauce: " + hamburgerLarge.getPrice());
console.log("Callories LARGE with sauce: " + hamburgerLarge.getCallories());