alert('3! = ' + factorial(3) + '\n5! = ' + factorial(5))

function factorial(i) {
  if (i === 0) { return 1 }
  else {return i * factorial (--i)}
}

