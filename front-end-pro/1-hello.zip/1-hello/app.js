let firstName = 'Nameless Person'
firstName = prompt('insert you Name:', 'John')
if (firstName === null) {
    firstName = 'Nameless Person'
    }
else if (firstName === 'Vadim') {
    alert('Привет тёзка, как дела?')
    }
alert('Hello ' + firstName + '! How are you?')